-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 12, 2019 at 12:06 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `e_commerce_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `order_table`
--

CREATE TABLE `order_table` (
  `order_no` int(11) NOT NULL,
  `serialized_orderedProductIdQtyArray` text NOT NULL,
  `customer_fullName` varchar(150) NOT NULL,
  `customer_eMail` varchar(150) NOT NULL,
  `customer_address` varchar(5000) NOT NULL,
  `customer_contact` int(11) NOT NULL,
  `orderTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `orderDeliveryComplete` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_table`
--

INSERT INTO `order_table` (`order_no`, `serialized_orderedProductIdQtyArray`, `customer_fullName`, `customer_eMail`, `customer_address`, `customer_contact`, `orderTime`, `orderDeliveryComplete`) VALUES
(1, 'a:2:{i:6;i:4;i:13;s:1:\"3\";}', 'asd', 'asd@asd.com', 'asdasd', 123, '2019-01-12 13:16:19', 0),
(2, 'a:2:{i:6;i:4;i:13;s:1:\"3\";}', 'asd', 'asd@asd.com', 'dsadsa', 345, '2019-01-12 13:17:23', 0);

-- --------------------------------------------------------

--
-- Table structure for table `product_category`
--

CREATE TABLE `product_category` (
  `category_id` int(11) NOT NULL,
  `shop_id` int(11) NOT NULL,
  `category_name` varchar(512) NOT NULL,
  `category_description` text,
  `added_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_category`
--

INSERT INTO `product_category` (`category_id`, `shop_id`, `category_name`, `category_description`, `added_time`) VALUES
(1, 1, 'category 1', 'des 1', '2019-01-05 15:32:35'),
(2, 2, 'category 1', 'des 1', '2019-01-05 15:32:35'),
(4, 1, 'category 1', 'des 1', '2019-01-05 15:32:56'),
(5, 2, 'category 1', 'des 1', '2019-01-05 15:32:56'),
(7, 1, 'category 1', 'des 1', '2019-01-05 15:38:11'),
(8, 1, 'category 1', 'des 1', '2019-01-05 15:38:19'),
(9, 2, 'category 1', NULL, '2019-01-05 15:38:56'),
(10, 2, 'category3', 'des3', '2019-01-05 15:46:05'),
(11, 1, 'category4', 'des4', '2019-01-05 15:46:35'),
(12, 1, 'cat3', NULL, '2019-01-05 17:07:41'),
(13, 2, 'cat4', NULL, '2019-01-05 17:08:44'),
(14, 1, 'cat5', 'des5', '2019-01-05 17:11:59');

-- --------------------------------------------------------

--
-- Table structure for table `product_table`
--

CREATE TABLE `product_table` (
  `product_id` int(11) NOT NULL,
  `product_category_id` int(11) NOT NULL,
  `product_name` varchar(512) NOT NULL,
  `product_price` float DEFAULT '0',
  `product_amount` int(11) DEFAULT '0',
  `product_image` longblob,
  `product_description` text,
  `added_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_table`
--

INSERT INTO `product_table` (`product_id`, `product_category_id`, `product_name`, `product_price`, `product_amount`, `product_image`, `product_description`, `added_time`) VALUES
(1, 1, 'product1', 40.75, 2, NULL, 'Des2', '2019-01-05 18:47:19'),
(2, 1, 'product2', NULL, NULL, NULL, 'newProductDes', '2019-01-05 18:47:38'),
(3, 1, 'a', NULL, NULL, NULL, 's', '2019-01-05 20:28:31'),
(4, 11, 'we', NULL, NULL, NULL, NULL, '2019-01-05 20:29:10'),
(5, 1, 'product3', 100, 14, NULL, 'des3', '2019-01-06 09:43:07'),
(6, 1, 'product4', 100.5, 10, NULL, 'des4', '2019-01-06 09:53:14'),
(7, 1, 'product5', 0, 10, NULL, 'des5', '2019-01-06 09:53:48'),
(9, 1, 'product7', 0, 0, NULL, NULL, '2019-01-06 10:04:23'),
(10, 1, 'product8', 0, 0, 0x496d616765204e6f7420417661696c61626c65, NULL, '2019-01-06 18:31:41'),
(11, 1, 'product9', 0, 0, '', NULL, '2019-01-06 18:38:04'),
(12, 1, 'product10', 0, 0, 0x496d616765204e6f7420417661696c61626c6521, NULL, '2019-01-06 18:39:05'),
(13, 1, 'product11', 500, 15, 0x496d616765204e6f7420417661696c61626c6521, 'des15', '2019-01-06 18:40:51');

-- --------------------------------------------------------

--
-- Table structure for table `registrationtable`
--

CREATE TABLE `registrationtable` (
  `id` int(11) NOT NULL,
  `fullName` varchar(100) NOT NULL,
  `eMail` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `reg_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` int(11) DEFAULT '0',
  `approved` int(11) NOT NULL DEFAULT '0',
  `admin` int(11) DEFAULT '0',
  `activationCode` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registrationtable`
--

INSERT INTO `registrationtable` (`id`, `fullName`, `eMail`, `password`, `reg_date`, `status`, `approved`, `admin`, `activationCode`) VALUES
(1, 'abc', 'abc@abc.com', '$2y$10$6Z0zSgU/cGmoK27luyVH0Ovs.GfUyFiR9N8juqnJltYHSICO2uQhS', '2019-01-09 13:20:41', 1, 1, 1, NULL),
(2, 'aaa', 'aaa@aaa.com', '$2y$10$lpqTEEiazzU.H7gZVAsmM.ioCmOMA94f/ZaKBPsWmBZ6Bqvx7mZfK', '2019-01-09 15:21:19', 1, -1, 0, NULL),
(3, 'Fathad Hossain', 'ffarhadcse032@gmail.com', '$2y$10$Gq.6aTBJICVRkdbfU/nox.G72HA8XtIrUktIm7e1DQI9JKIwVqJ5a', '2019-01-09 15:21:13', 1, 1, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `shop_table`
--

CREATE TABLE `shop_table` (
  `shop_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `approved` int(11) NOT NULL DEFAULT '0',
  `shop_name` varchar(512) NOT NULL,
  `shop_description` text,
  `added_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shop_table`
--

INSERT INTO `shop_table` (`shop_id`, `member_id`, `approved`, `shop_name`, `shop_description`, `added_time`) VALUES
(1, 1, 1, 'shop1', 'des1', '2019-01-05 13:16:42'),
(2, 1, -1, 'shop2', 'des2', '2019-01-05 13:17:07'),
(3, 1, 1, 'shop3 update', 'des3', '2019-01-05 17:12:17'),
(4, 1, 1, 'shop4', 'des 4', '2019-01-09 18:58:10');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `order_table`
--
ALTER TABLE `order_table`
  ADD PRIMARY KEY (`order_no`);

--
-- Indexes for table `product_category`
--
ALTER TABLE `product_category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `product_table`
--
ALTER TABLE `product_table`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `registrationtable`
--
ALTER TABLE `registrationtable`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `eMail` (`eMail`);

--
-- Indexes for table `shop_table`
--
ALTER TABLE `shop_table`
  ADD PRIMARY KEY (`shop_id`),
  ADD UNIQUE KEY `shop_name` (`shop_name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `order_table`
--
ALTER TABLE `order_table`
  MODIFY `order_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `product_category`
--
ALTER TABLE `product_category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `product_table`
--
ALTER TABLE `product_table`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `registrationtable`
--
ALTER TABLE `registrationtable`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `shop_table`
--
ALTER TABLE `shop_table`
  MODIFY `shop_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
